import React, { useEffect, useState } from 'react';
import { Box, Button, Dialog, DialogContent } from '@mui/material';
import { DataGrid, GridToolbar } from '@mui/x-data-grid';
import { useTheme } from '@mui/material';
import api from '../../api'; // Import the axios instance
import { tokens } from '../../theme';
import Header from '../../components/Header';
import ContactForm from '../../scenes/form';

const Contacts = () => {
  const [contacts, setContacts] = useState([]);
  const [isFormOpen, setIsFormOpen] = useState(false);
  const theme = useTheme();
  const colors = tokens(theme.palette.mode);

const fetchContacts = async () => {
    try {
      const response = await api.get('contacts'); // Use the axios instance
      setContacts(response.data);

    } catch (error) {
      console.error('Error fetching contacts:', error);
    }
  };

  // Function to open the modal
  const handleOpenForm = () => {
    setIsFormOpen(true);
  };

  // Function to close the modal
  const handleCloseForm = () => {
    setIsFormOpen(false);
    fetchContacts();
  };

  const columns = [
    { field: 'id', headerName: 'ID', flex: 0.5 },
    { field: 'registrarId', headerName: 'Registrar ID' },
    { field: 'name', headerName: 'Name', flex: 1 },
    { field: 'age', headerName: 'Age', type: 'number' },
    { field: 'phone', headerName: 'Phone Number', flex: 1 },
    { field: 'email', headerName: 'Email', flex: 1 },
    { field: 'address', headerName: 'Address', flex: 1 },
    { field: 'city', headerName: 'City', flex: 1 },
    { field: 'zipCode', headerName: 'Zip Code', flex: 1 },
  ];

  useEffect(() => {
    fetchContacts();
  }, []);

  return (
    <Box m="20px">
      <Header
        title="CONTACTS"
        subtitle="List of Contacts for Future Reference"
      />
      <Button
        variant="contained"
        onClick={handleOpenForm}
        color="secondary"
        sx={{ 
          //backgroundColor: colors.greenAccent[400],
          mb: 2 
        }}
      >
        Add New Contact
      </Button>
      <Dialog open={isFormOpen} onClose={handleCloseForm} maxWidth="md" fullWidth>
        <DialogContent>
          <ContactForm onSuccess={handleCloseForm} />
        </DialogContent>
      </Dialog>     
      <Box
        m="10px 0 0 0"
        height="75vh"
        sx={{
          '& .MuiDataGrid-root': { border: 'none' },
          '& .MuiDataGrid-cell': { borderBottom: 'none' },
          '& .name-column--cell': { color: colors.greenAccent[300] },
          '& .MuiDataGrid-columnHeaders': {
            backgroundColor: colors.blueAccent[700],
            borderBottom: 'none',
          },
          '& .MuiDataGrid-virtualScroller': {
            backgroundColor: colors.primary[400],
          },
          '& .MuiDataGrid-footerContainer': {
            borderTop: 'none',
            backgroundColor: colors.blueAccent[700],
          },
          '& .MuiCheckbox-root': {
            color: `${colors.greenAccent[200]} !important`,
          },
          '& .MuiDataGrid-toolbarContainer .MuiButton-text': {
            color: `${colors.grey[100]} !important`,
          },
        }}
      >
        <DataGrid
          rows={contacts}
          columns={columns}
          components={{ Toolbar: GridToolbar }}
        />
      </Box>
    </Box>
  );
};

export default Contacts;